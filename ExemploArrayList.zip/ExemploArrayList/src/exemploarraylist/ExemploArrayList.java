
package exemploarraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class ExemploArrayList {

    public static void main(String[] args) {
       //manipulação de Arraylist
       //estruturas de dados dinâmicas
       
       //criar uma lista de dados
       /*
       ArrayList<Double> notas = new ArrayList<>();
       
        notas.add(1.0);
        notas.add(2.0);
        notas.add(3.0);
       
        System.out.println(notas.get(0));
        System.out.println(notas.get(1));
        System.out.println(notas.get(2));
        
        System.out.println(notas.size());
        
        notas.add(2,5.0);
       
        System.out.println(notas.get(0));
        System.out.println(notas.get(1));
        System.out.println(notas.get(2));
        
        System.out.println(notas.indexOf(2.0));
        
        System.out.println(notas.isEmpty());
        
        notas.clear();
        
        System.out.println(notas.isEmpty());
        
        notas.add(1.0);
        notas.add(2.0);
        notas.add(3.0);
        
        notas.remove(1);
        
        System.out.println(notas.get(0));
        System.out.println(notas.get(1));
        System.out.println(notas.get(2));
        */
       
       Scanner sc = new Scanner(System.in);
       
       Pessoa p1 = new Pessoa();
       
        System.out.println("Digite o nome da pessoa:");
        //String p = sc.nextLine();
        p1.setNome(sc.nextLine());
        
        ArrayList<Telefone> telefones = new ArrayList<>();
        
        System.out.println("Digite os telefones: 3 opções");
        for(int i = 0; i < 3; i++){
            Telefone t = new Telefone();
            System.out.println("Digite o numero: ");
            
            t.setNumero(sc.nextLine());
            telefones.add(t);
        }
        p1.setTelefone(telefones);
        p1.imprimir();
    }
    
}
