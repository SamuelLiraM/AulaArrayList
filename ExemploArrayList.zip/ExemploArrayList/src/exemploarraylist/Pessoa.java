
package exemploarraylist;

import java.util.ArrayList;

public class Pessoa {
    private String nome;
    //atributo do tipo lista
    private ArrayList<Telefone>telefone;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Telefone> getTelefone() {
        return telefone;
    }

    public void setTelefone(ArrayList<Telefone> telefone) {
        this.telefone = telefone;
    }
    
    public void imprimir(){
        System.out.println("Nome: "+getNome());
        System.out.println("Telefones: ");
        for(int i = 0; i < getTelefone().size(); i++){
            getTelefone().get(i).imprimirTelefone();
        }
    }
}
